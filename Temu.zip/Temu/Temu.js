const { Builder, By, until } = require('selenium-webdriver');

async function searchTemu(query) {
    // Initialize the WebDriver
    let driver = await new Builder().forBrowser('chrome').build();

    try {
        // Open Temu website
        await driver.get("https://www.temu.com/");
        await driver.manage().window().maximize();
        await driver.sleep(5000); // Wait for the page to load

        // Search for the query
        const searchBox = await driver.wait(
            until.elementLocated(By.xpath("//span[@class='shadeWord-2xL2I']")),
            10000
        );
        await searchBox.sendKeys(query, Key.RETURN);
        await driver.sleep(5000);

        // Click on the "Sort By" dropdown
        const clickOnSortBy = await driver.findElement(By.xpath("(//span[@class='_1IIB2fxD'])[2]"));
        await clickOnSortBy.click();

        // Select "Price Low to High"
        const priceLowToHigh = await driver.wait(
            until.elementLocated(By.xpath("(//li[@class='_3NztH4Nl'])[4]")),
            10000
        );
        await priceLowToHigh.click();
        await driver.sleep(5000); // Wait for the sorted results to load

        // Extract product details
        const products = [];
        const results = await driver.findElements(By.xpath("//div[@class='_6q6qVUF5 _1QhQr8pq _3AbcHYoU']"));

        for (const result of results) {
            try {
                const title = await result.findElement(By.xpath("//div[@class='_6q6qVUF5 _1QhQr8pq _3AbcHYoU']")).getText();
                const url = await result.findElement(By.xpath("//div[@class='_6q6qVUF5 _1QhQr8pq _3AbcHYoU']")).getAttribute("href");
                const image = await result.findElement(By.tagName("img")).getAttribute("src");
                const price = await result.findElement(By.xpath("//div[@class='_382YgpSF']")).getText();
                const reviews = await result.findElement(By.xpath("//div[@class='_3tAUu0RX _1QhQr8pq']")).getText();
                products.push({
                    title: title,
                    url: url,
                    image: image,
                    price: price,
                    reviews: reviews
                });
            } catch (e) {
                // Skip incomplete product listings
                continue;
            }
        }

        return products;

    } catch (error) {
        console.error(`An error occurred: ${error}`);
        return [];
    } finally {
        // Quit the WebDriver
        await driver.quit();
    }
}

// Example usage
(async () => {
    const query = "laptop"; // Example query
    const results = await searchTemu(query);

    results.forEach((product, index) => {
        console.log(`Product ${index + 1}:`);
        console.log(`Title: ${product.title}`);
        console.log(`URL: ${product.url}`);
        console.log(`Image: ${product.image}`);
        console.log(`Price: ${product.price}`);
        console.log(`Reviews: ${product.reviews}`);
        console.log('-'.repeat(80));
    });
})();
