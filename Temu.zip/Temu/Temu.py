from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()
def search_temu(query):
    try:
        # Open Temu website
        driver.get("https://www.temu.com/")
        driver.maximize_window()
        time.sleep(5)
        # Search for the query
        search_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//span[@class='shadeWord-2xL2I']"))
        )
        search_box.send_keys(query)
        search_box.send_keys(Keys.RETURN)
        time.sleep(5)

        click_on_sort_by = driver.find_element(By.XPATH, "(//span[@class='_1IIB2fxD'])[2]")
        click_on_sort_by.click()

        price_low_to_high = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "(//li[@class='_3NztH4Nl'])[4]"))
        )
        price_low_to_high.click()
        time.sleep(5)  # Wait for the sorted results to load

        # Extract product details
        products = []
        results = driver.find_elements(By.XPATH, "//div[@class='_6q6qVUF5 _1QhQr8pq _3AbcHYoU']")
        for result in results:
            try:
                title = result.find_element(By.XPATH, "//div[@class='_6q6qVUF5 _1QhQr8pq _3AbcHYoU']").text
                url = result.find_element(By.XPATH, "//div[@class='_6q6qVUF5 _1QhQr8pq _3AbcHYoU']").get_attribute("href")
                image = result.find_element(By.TAG_NAME, "img").get_attribute("src")
                price = result.find_element(By.XPATH, "//div[@class='_382YgpSF']").text
                reviews = result.find_element(By.XPATH, "//div[@class='_3tAUu0RX _1QhQr8pq']").text
                products.append({
                    "title": title,
                    "url": url,
                    "image": image,
                    "price": price,
                    "reviews": reviews
                })
            except Exception as e:
                # Skip incomplete product listings
                continue

        return products

    except Exception as e:
        print(f"An error occurred: {e}")
        return []
    finally:
        driver.quit()

# Example usage
if __name__ == "__main__":
    search_query = input("Enter the product to search: ")
    results = search_temu(search_query)
    for idx, product in enumerate(results, start=1):
        print(f"Product {idx}:")
        print(f"Title: {product['title']}")
        print(f"URL: {product['url']}")
        print(f"Image: {product['image']}")
        print(f"Price: {product['price']}")
        print(f"Reviews: {product['reviews']}")
        print("-" * 80)
